<html>
<body style="background-color:#20001c;color:white;font-size:200%">
<div style="text-align:center;font-size:500%">1ctpack</div>
16x16 icons galore! 50 and adding included.
**NOTE: THIS IS STILL IN A BETA PHASE!!! IF YOU HAVE NOT GOTTEN THIS OFF OF DISCORD, THIS IS LIKELY PIRATED.**
## Extension Settings
To choose File Icons, Go to File > Prefrences > File Icon Theme, and click "1ct-pack."

<span style="color:red;font-size:150%;">**THESE ICONS ARE 16x16. IT IS HEAVILY ADVISED THAT YOU CHANGE THE ZOOM SO IT DOESNT LOOK BLURRY.**</span>

## Rights

Many of these icons are based off of the work of Microsoft™ (Mojang Studios™), Oracle™, Google™, Apple™, Winrar, and the Material icon theme. 

However, they are all modified under fair use.

This pack also falls under the MIT license.

## Contact me

For Buisness Inqueries, go PM me at u/1ctinus on Reddit™.

**Enjoy!**
</body>
</html>
